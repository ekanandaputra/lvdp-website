
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Monitoring LVDP - Tabel</h1> <br>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Monitoring Power Quality Line R</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="data-table-list">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="lineR" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                        <th>Tegangan</th>
                                        <th>Arus</th>
                                        <th>Real Power</th>
                                        <th>Apparent Power</th>
                                        <th>Power Factor</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 0;?>
                                    <?php $__currentLoopData = $sensor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $no++;
                                        $date = explode(' ',$data->created_at);
                                    ;?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($date[0]); ?></td>
                                        <td><?php echo e($date[1]); ?></td>
                                        <td><?php echo e($data->voltage_r); ?></td>
                                        <td><?php echo e($data->current_r); ?></td>
                                        <td><?php echo e($data->power_r); ?></td>
                                        <td><?php echo e($data->apparent_power_r); ?></td>
                                        <td><?php echo e($data->power_factor_r); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Monitoring Power Quality Line S</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="data-table-list">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="lineS" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                        <th>Tegangan</th>
                                        <th>Arus</th>
                                        <th>Real Power</th>
                                        <th>Apparent Power</th>
                                        <th>Power Factor</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 0;?>
                                    <?php $__currentLoopData = $sensor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $no++;
                                        $date = explode(' ',$data->created_at);
                                    ;?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($date[0]); ?></td>
                                        <td><?php echo e($date[1]); ?></td>
                                        <td><?php echo e($data->voltage_s); ?></td>
                                        <td><?php echo e($data->current_s); ?></td>
                                        <td><?php echo e($data->power_s); ?></td>
                                        <td><?php echo e($data->apparent_power_s); ?></td>
                                        <td><?php echo e($data->power_factor_s); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Monitoring Power Quality Line T</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="data-table-list">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="lineT" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                        <th>Tegangan</th>
                                        <th>Arus</th>
                                        <th>Real Power</th>
                                        <th>Apparent Power</th>
                                        <th>Power Factor</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 0;?>
                                    <?php $__currentLoopData = $sensor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $no++;
                                        $date = explode(' ',$data->created_at);
                                    ;?>
                                    <tr>
                                        <td><?php echo e($no); ?></td>
                                        <td><?php echo e($date[0]); ?></td>
                                        <td><?php echo e($date[1]); ?></td>
                                        <td><?php echo e($data->voltage_t); ?></td>
                                        <td><?php echo e($data->current_t); ?></td>
                                        <td><?php echo e($data->power_t); ?></td>
                                        <td><?php echo e($data->apparent_power_t); ?></td>
                                        <td><?php echo e($data->power_factor_t); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\lvdp\resources\views/content/table.blade.php ENDPATH**/ ?>